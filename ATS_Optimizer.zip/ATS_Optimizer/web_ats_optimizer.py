from pathlib import Path
import streamlit as st
from docx import Document
import pdfplumber
import subprocess
import os
import re
import logging
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import unicodedata
from datetime import datetime

# Must be the first Streamlit command
st.set_page_config(layout="wide", page_title="ATS CV Optimizer Pro – Web")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='ats_optimizer.log'
)

# Constants
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
MAX_PROMPT_LENGTH = 8000  # Max chars for ollama prompt

# Default prompts (fallback if files are missing)
DEFAULT_PROMPTS = {
    "consultant": "[INST] Perform a technical audit of the CV for the specified role, analyzing ATS compatibility, keywords, and job alignment. Provide an ATS score (1-10), keyword audit, and improvement suggestions. [/INST]",
    "client": "[INST] Generate a client-friendly summary for the specified role, highlighting CV strengths, ATS compatibility (1-10), and top missed opportunities. Include a call to action. [/INST]",
    "optimization": "[INST] Optimize the CV for the specified role, creating an ATS-compliant version with a header, summary, skills, experience, certifications, education, tools, and languages. Use .docx-safe formatting. [/INST]",
    "self_audit": "[INST] Analyze the CV for ATS compatibility without a job description. Provide an ATS score (1-10), identify key strengths, missing industry-standard keywords, and suggest improvements for the specified role. [/INST]",
    "compare": "[INST] Compare the CV and JD in detail. Provide: 1. Key skills match (present/missing) 2. Experience alignment 3. Recommendations for CV improvement 4. Overall fit score (1-10) [/INST]"
}

# Keyword weights and tool mapping
KEYWORD_WEIGHTS = {
    "safety": 1.5, "nebosh": 2.0, "iwcf": 2.0,
    "pmp": 1.8, "drilling": 1.3, "offshore": 1.4,
    "hse": 1.6, "petrel": 1.5, "aspen": 1.4,
    "primav": 1.3, "simops": 1.7, "hazop": 1.7
}

TOOL_MAPPING = {
    "aspen hysys": ["hysys", "aspen plus"],
    "primav": ["primavera p6", "p6"],
    "petrel": ["schlumberger petrel"],
    "cmms": ["computerized maintenance management system"],
    "lims": ["laboratory information management system"]
}

def load_prompts():
    """Load prompt templates from files with fallback to defaults, returning prompts and errors."""
    prompts = {}
    errors = []
    prompt_files = {
        "consultant": "prompt_audit_consultant.txt",
        "client": "prompt_audit_client.txt",
        "optimization": "prompt_audit_optimization.txt",
        "self_audit": "prompt_audit_self_audit.txt",
        "compare": "prompt_compare_cv_jd.txt"
    }
    script_dir = Path(__file__).parent
    for key, filename in prompt_files.items():
        try:
            file_path = script_dir / filename
            if file_path.exists():
                with open(file_path, "r", encoding="utf-8") as f:
                    prompts[key] = f.read()
            else:
                logging.warning(f"Prompt file not found: {file_path}. Using default prompt.")
                prompts[key] = DEFAULT_PROMPTS[key]
                errors.append(f"Prompt file {filename} not found. Using default prompt.")
        except Exception as e:
            logging.error(f"Error loading prompt {filename}: {str(e)}")
            prompts[key] = DEFAULT_PROMPTS[key]
            errors.append(f"Error loading {filename}: {str(e)}. Using default prompt.")
    return prompts, errors

def extract_text(file):
    """Extract text from uploaded file."""
    if file.name.endswith('.docx'):
        doc = Document(file)
        text = []
        for para in doc.paragraphs:
            if para.text.strip():
                text.append(para.text)
        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                if row_text:
                    text.append(" | ".join(row_text))
        return "\n".join(text)
    elif file.name.endswith('.pdf'):
        with pdfplumber.open(file) as pdf:
            return "\n".join([page.extract_text() or '' for page in pdf.pages])
    else:
        return file.read().decode("utf-8")

def clean_text(text):
    """Clean text for analysis."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def sanitize_text_for_display(text):
    """Sanitize text for display."""
    if not isinstance(text, str):
        text = str(text)
    text = unicodedata.normalize('NFKD', text)
    return text.encode('utf-8', errors='replace').decode('utf-8')

def keyword_check(text):
    """Check for oil & gas industry keywords."""
    oil_gas_keywords = [
        "drilling", "petrel", "hse", "safety", "offshore",
        "onshore", "well", "reservoir", "production", "pipeline",
        "simops", "hazop", "nebosh", "iwcf", "pmp",
        "sap", "primavera", "aspen", "cmms", "lims"
    ]
    found = [kw for kw in oil_gas_keywords if kw.lower() in text.lower()]
    missing = [kw for kw in oil_gas_keywords if kw.lower() not in text.lower()]
    return found, missing

def apply_keyword_weights(cv_text, jd_text, base_score):
    """Apply weights to keywords for scoring."""
    weighted_score = base_score
    for keyword, weight in KEYWORD_WEIGHTS.items():
        if keyword in jd_text.lower():
            if keyword in cv_text.lower():
                weighted_score *= (1 + (weight - 1) * 0.1)
            else:
                weighted_score *= (1 - (weight - 1) * 0.15)
    return min(100, weighted_score)

def extract_cv_sections(text):
    """Extract CV sections (experience, skills, education)."""
    sections = {}
    section_headers = ["experience", "skills", "education", "certifications"]
    text_lower = text.lower()
    for i, header in enumerate(section_headers):
        pattern = rf"\b{header}\b"
        match = re.search(pattern, text_lower, re.IGNORECASE)
        if match:
            start = match.start()
            end = len(text)
            if i + 1 < len(section_headers):
                next_match = re.search(rf"\b{section_headers[i+1]}\b", text_lower[start:], re.IGNORECASE)
                if next_match:
                    end = start + next_match.start()
            sections[header.upper()] = text[start:end]
    return sections

def match_experience(exp_text, jd_text):
    """Match CV experience to JD requirements."""
    exp_match = re.search(r"(\d+)\s*(year|yr|лет)", jd_text, re.IGNORECASE)
    req_exp = int(exp_match.group(1)) if exp_match else 0
    user_exp = 0
    exp_years = re.findall(r"(\d+)\s*(year|yr|лет)", exp_text, re.IGNORECASE)
    if exp_years:
        user_exp = max(int(y[0]) for y in exp_years)
    return 100 if req_exp == 0 else min(100, (user_exp / req_exp) * 100)

def normalize_tools(text):
    """Normalize tool names."""
    normalized = []
    for tool, variants in TOOL_MAPPING.items():
        if any(variant in text.lower() for variant in variants + [tool]):
            normalized.append(tool)
    return normalized

def match_skills(skills_text, jd_text):
    """Match CV skills to JD requirements."""
    normalized_skills = normalize_tools(skills_text)
    required_skills = set(re.findall(r"\b([A-Za-z]+ \w+|\w+)\b", jd_text))
    matches = sum(1 for skill in required_skills if any(norm_skill in skill.lower() for norm_skill in normalized_skills))
    return (matches / len(required_skills)) * 100 if required_skills else 100

def match_education(edu_text, jd_text):
    """Match CV education to JD requirements."""
    edu_keywords = ["bachelor", "master", "phd", "degree", "diploma"]
    req_edu = any(keyword in jd_text.lower() for keyword in edu_keywords)
    has_edu = any(keyword in edu_text.lower() for keyword in edu_keywords)
    return 100 if not req_edu else (100 if has_edu else 0)

def analyze_sections(cv_text, jd_text):
    """Analyze CV sections for scoring."""
    sections = extract_cv_sections(cv_text)
    score = 0
    if 'EXPERIENCE' in sections:
        score += match_experience(sections['EXPERIENCE'], jd_text) * 0.4
    if 'SKILLS' in sections:
        score += match_skills(sections['SKILLS'], jd_text) * 0.3
    if 'EDUCATION' in sections:
        score += match_education(sections['EDUCATION'], jd_text) * 0.2
    return min(100, score * 100)

def enhanced_compare_texts(cv_text, jd_text):
    """Perform enhanced ATS match analysis."""
    try:
        vectorizer = TfidfVectorizer(ngram_range=(1, 3), stop_words='english', max_features=5000)
        tfidf_matrix = vectorizer.fit_transform([cv_text, jd_text])
        base_score = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0] * 100
        weighted_score = apply_keyword_weights(cv_text, jd_text, base_score)
        sections_score = analyze_sections(cv_text, jd_text)
        final_score = (base_score * 0.4 + weighted_score * 0.4 + sections_score * 0.2)
        return round(final_score, 1)
    except Exception as e:
        logging.error(f"Text comparison failed: {str(e)}")
        return 0.0

def run_ollama(prompt):
    """Run Ollama command with prompt."""
    try:
        if len(prompt) > MAX_PROMPT_LENGTH:
            prompt = prompt[:MAX_PROMPT_LENGTH - 100] + "... [truncated]"
            logging.warning("Prompt truncated to fit max length")
        result = subprocess.run(
            ["ollama", "run", "mistral:7b-instruct-v0.2-q5_K_M", prompt],
            capture_output=True,
            text=True,
            check=True,
            encoding='utf-8'
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        logging.error(f"Ollama error: {e.stderr}")
        return f"Error: {e.stderr}"
    except Exception as e:
        logging.error(f"Ollama error: {str(e)}")
        return f"Error: {str(e)}"

def export_docx(text, filename):
    """Export text to .docx file."""
    doc = Document()
    for line in text.splitlines():
        doc.add_paragraph(line)
    export_path = Path(filename)
    doc.save(export_path)
    return export_path

def generate_recommendations(score, missing_certs):
    """Generate recommendations based on score and missing certifications."""
    thresholds = {80: "Your CV is well aligned. Consider highlighting: ",
                  60: "Your CV needs moderate improvements. Focus on: ",
                  0: "Your CV requires significant changes. Priority areas: "}
    base = thresholds[next(k for k in [80, 60, 0] if score >= k)]
    return base + (f"obtaining {next(iter(missing_certs))} certification" if missing_certs else "adding more relevant keywords from the job description")

def get_weakest_area(cv_text, jd_text):
    """Identify weakest CV section."""
    sections = extract_cv_sections(cv_text)
    scores = {}
    if 'EXPERIENCE' in sections:
        scores['experience'] = match_experience(sections['EXPERIENCE'], jd_text)
    if 'SKILLS' in sections:
        scores['skills'] = match_skills(sections['SKILLS'], jd_text)
    return min(scores, key=scores.get) if scores else "skills"

# Load prompt files (after set_page_config)
prompts, prompt_errors = load_prompts()

# Display prompt loading errors, if any
if prompt_errors:
    for error in prompt_errors:
        st.warning(error)

# Display logo in top-left corner
logo_path = Path(__file__).parent / "EHSphere.png"
if logo_path.exists():
    try:
        st.image(str(logo_path), width=180)
    except Exception as e:
        logging.error(f"Failed to load logo: {str(e)}")
        st.warning(f"Failed to load logo: {str(e)}")
else:
    logging.warning(f"Logo file not found: {logo_path}")
    st.warning("Logo file 'EHSphere.png' not found.")

st.title("📄 ATS CV Optimizer Pro – Web Edition")

col1, col2 = st.columns(2)

with col1:
    st.subheader("1️⃣ Upload CV")
    cv_file = st.file_uploader("Choose CV file", type=["docx", "pdf", "txt"], key="cv_uploader")
    cv_text = extract_text(cv_file) if cv_file else ""
    if cv_text:
        st.text_area("CV Preview", sanitize_text_for_display(cv_text), height=300, key="cv_preview")

with col2:
    st.subheader("2️⃣ Upload Job Description / Other Candidate CV")
    jd_file = st.file_uploader("Choose JD file", type=["docx", "pdf", "txt"], key="jd_uploader")
    jd_text = extract_text(jd_file) if jd_file else ""
    if jd_text:
        st.text_area("JD Preview", sanitize_text_for_display(jd_text), height=300, key="jd_preview")

if cv_text and jd_text:
    role = st.text_input("🎯 Target Role", value="HSE Manager", key="role_input")
    context = st.text_area("🛠️ Context (certifications, experience, projects)", value="NEBOSH, IOSH, Aramco, pipelines, etc.", key="context_input")
    
    # Perform keyword check
    found_keywords, missing_keywords = keyword_check(cv_text)
    cv_raw = clean_text(cv_text)
    jd_raw = clean_text(jd_text)

    st.subheader("🧠 Available Actions")
    st.markdown("**ATS Match Score: <span id='ats_score'>-</span>**", unsafe_allow_html=True)

    actions = {
        "🔍 Analyze ATS Match": {"type": "custom", "func": lambda: enhanced_compare_texts(cv_raw, jd_raw)},
        "📊 Compare CV vs JD": {"type": "prompt", "key": "compare"},
        "📈 Full AI Audit": {"type": "prompt", "key": "consultant"},
        "🧾 Internal Audit": {"type": "prompt", "key": "consultant", "internal_only": True},
        "🗂 Client Summary": {"type": "prompt", "key": "client"},
        "🔧 Improve CV": {"type": "prompt", "key": "optimization"},
        "🔍 CV Self-Audit": {"type": "prompt", "key": "self_audit"}
    }

    for label, action in actions.items():
        if st.button(label, key=label.replace(" ", "_")):
            with st.spinner(f"Running {label}..."):
                start_time = datetime.now()
                logging.info(f"Started {label}...")
                
                if action["type"] == "custom":
                    # Handle Analyze ATS Match with TF-IDF and custom logic
                    score = action["func"]()
                    required_certs = set(re.findall(r"(API \d+|NEBOSH|IWCF|PMP)", jd_text, re.IGNORECASE))
                    user_certs = set(re.findall(r"(API \d+|NEBOSH|IWCF|PMP)", cv_text, re.IGNORECASE))
                    vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
                    jd_vector = vectorizer.fit_transform([jd_raw])
                    feature_names = vectorizer.get_feature_names_out()
                    sorted_indices = np.argsort(jd_vector.toarray())[0][-10:]
                    top_keywords = [feature_names[i] for i in sorted_indices[::-1]]
                    report = f"""
Enhanced ATS Analysis Report
----------------------------
Overall Match Score: {score}%

Key Metrics:
- Missing Certificates: {', '.join(required_certs - user_certs) or 'None'}
- Present Certificates: {', '.join(user_certs) or 'None'}

Top 10 Keywords from Job Description:
{', '.join(top_keywords)}

Recommendations:
1. {generate_recommendations(score, required_certs - user_certs)}
2. Focus on improving your {get_weakest_area(cv_text, jd_text)} section
"""
                    st.session_state.ats_score = score
                    st.markdown(f"**ATS Match Score: {score}%**", unsafe_allow_html=True)
                else:
                    # Handle prompt-based actions
                    prompt = prompts[action["key"]]
                    prompt = prompt.format(
                        role=role,
                        context=context,
                        cv_text=cv_text[:3000],
                        found_keywords=", ".join(found_keywords),
                        missing_keywords=", ".join(missing_keywords),
                        jd_text=jd_text[:3000] if label != "🔍 CV Self-Audit" else ""
                    )
                    if label == "🧾 Internal Audit":
                        prompt = f"[INST] {prompt}\n\nGenerate only the Internal Technical Audit Report.[/INST]"
                    result = run_ollama(prompt)
                    report = result
                    if label == "🧾 Internal Audit" and "---" in result:
                        report = result.split("---")[0].strip()
                    elif label == "🗂 Client Summary":
                        if "---" in result:
                            report = result.split("---")[1].strip() if len(result.split("---")) > 1 else result
                        elif "Client Summary Report" in result:
                            report = re.split(r"Client Summary Report", result, flags=re.IGNORECASE)[1].strip()
                        else:
                            report = result
                    elif label == "🔧 Improve CV":
                        hidden_keywords = found_keywords + missing_keywords
                        hidden_section = "\n\n[ATS Keywords (Hidden)]\n" + ", ".join(hidden_keywords)
                        report = result + hidden_section

                st.subheader(label)
                st.code(sanitize_text_for_display(report))

                docx_path = export_docx(report, "result.docx")
                with open(docx_path, "rb") as f:
                    st.download_button("💾 Download Report as .docx", f, file_name="AI_Report.docx", key=f"download_{label.replace(' ', '_')}")
                
                elapsed = (datetime.now - start_time).total_seconds()
                logging.info(f"{label} completed in {elapsed:.2f} seconds.")

else:
    st.info("Upload both CV and JD to activate AI tools.")

st.markdown("""
<hr>
<p style='text-align: center; font-size: 14px;'>
    Developed by <strong>Aleksandr Arkhipov</strong> |
    <a href="mailto:arkhipower@gmail.com">arkhipower@gmail.com</a> |
    <a href="https://www.linkedin.com/in/arkhipovhse" target="_blank">LinkedIn</a>
</p>
""", unsafe_allow_html=True)