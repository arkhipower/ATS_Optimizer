import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, simpledialog, ttk
from tkinter.font import Font
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from docx import Document
import pdfplumber
import os
import difflib
import logging
import webbrowser
import re
from datetime import datetime
from PIL import Image, ImageTk
import subprocess
import json
import numpy as np
from collections import defaultdict
import unicodedata
import sys

# --- Constants ---
DEFAULT_FONT = ("Segoe UI", 10)
MONOSPACE_FONT = ("Consolas", 10)
HEADER_FONT = ("Segoe UI", 12, "bold")
BUTTON_FONT = ("Segoe UI", 10, "bold")
PADX = 5
PADY = 3
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB limit
MAX_PROMPT_LENGTH = 8000  # Max chars for ollama prompt

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='ats_optimizer.log'
)

# Default prompts if files are missing
DEFAULT_PROMPTS = {
    "consultant": "[INST] Perform a technical audit of the CV for the specified role, analyzing ATS compatibility, keywords, and job alignment. Provide an ATS score (1-10), keyword audit, and improvement suggestions. [/INST]",
    "client": "[INST] Generate a client-friendly summary for the specified role, highlighting CV strengths, ATS compatibility (1-10), and top missed opportunities. Include a call to action. [/INST]",
    "optimization": "[INST] Optimize the CV for the specified role, creating an ATS-compliant version with a header, summary, skills, experience, certifications, education, tools, and languages. Use .docx-safe formatting. [/INST]",
    "self_audit": "[INST] Analyze the CV for ATS compatibility without a job description. Provide an ATS score (1-10), identify key strengths, missing industry-standard keywords, and suggest improvements for the specified role. [/INST]"
}

class ATSOptimizerApp:
    def __init__(self, root):
        self.root = root
        self.check_dependencies()
        self.setup_keyword_weights()
        self.setup_tool_mapping()
        self.load_prompts()
        self.setup_ui()
        self.setup_variables()

    def check_dependencies(self):
        """Check for required dependencies and alert user if missing"""
        try:
            import sklearn
            import pdfplumber
            import docx
            import PIL
        except ImportError as e:
            messagebox.showerror("Dependency Error", f"Missing dependency: {str(e)}. Please install required packages (scikit-learn, pdfplumber, python-docx, Pillow).")
            sys.exit(1)
        try:
            subprocess.run(["ollama", "--version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            messagebox.showerror("Ollama Error", "Ollama is not installed or not running. Install ollama and run 'ollama pull mistral:7b-instruct-v0.2-q5_K_M'.")
            sys.exit(1)

    def setup_keyword_weights(self):
        """Weights for oil & gas industry keywords"""
        self.keyword_weights = {
            "safety": 1.5, "nebosh": 2.0, "iwcf": 2.0,
            "pmp": 1.8, "drilling": 1.3, "offshore": 1.4,
            "hse": 1.6, "petrel": 1.5, "aspen": 1.4,
            "primav": 1.3, "simops": 1.7, "hazop": 1.7
        }

    def setup_tool_mapping(self):
        """Tool name normalization"""
        self.tool_mapping = {
            "aspen hysys": ["hysys", "aspen plus"],
            "primav": ["primavera p6", "p6"],
            "petrel": ["schlumberger petrel"],
            "cmms": ["computerized maintenance management system"],
            "lims": ["laboratory information management system"]
        }

    def load_prompts(self):
        """Load prompt templates from files with fallback"""
        self.prompts = {}
        prompt_files = {
            "consultant": "prompt_audit_consultant.txt",
            "client": "prompt_audit_client.txt",
            "optimization": "prompt_audit_optimization.txt",
            "self_audit": "prompt_audit_self_audit.txt"
        }
        script_dir = os.path.dirname(os.path.abspath(__file__))
        for key, filename in prompt_files.items():
            try:
                file_path = os.path.join(script_dir, filename)
                if os.path.exists(file_path):
                    with open(file_path, "r", encoding="utf-8") as f:
                        self.prompts[key] = f.read()
                else:
                    logging.warning(f"Prompt file not found: {file_path}. Using default prompt.")
                    self.prompts[key] = DEFAULT_PROMPTS[key]
                    messagebox.showwarning("Prompt Warning", f"Prompt file {filename} not found. Using default prompt.")
            except Exception as e:
                logging.error(f"Error loading prompt {filename}: {str(e)}")
                self.prompts[key] = DEFAULT_PROMPTS[key]
                messagebox.showwarning("Prompt Error", f"Error loading {filename}. Using default prompt.")

    def setup_variables(self):
        self.cv_raw = None
        self.cv_original = None
        self.cv_improved = None
        self.jd_raw = None
        self.jd_original = None
        self.jd_audit = None

    def setup_ui(self):
        self.root.title("ATS CV Optimizer Pro - Audit Edition")
        self.root.geometry("1200x900")
        self.style = ttk.Style()
        self.style.configure("TButton", font=BUTTON_FONT, padding=5)
        self.style.configure("TLabel", font=DEFAULT_FONT)
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.create_header()
        self.create_load_section()
        self.create_cv_section()
        self.create_action_buttons()
        self.create_jd_section()
        self.create_status_bar()
        self.create_log_section()

    def create_header(self):
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        logo_path = os.path.join(os.path.dirname(__file__), "EHSphere.png")
        if os.path.exists(logo_path):
            try:
                img = Image.open(logo_path)
                img = img.resize((180, 150))
                self.logo = ImageTk.PhotoImage(img)
                logo_label = ttk.Label(header_frame, image=self.logo)
                logo_label.pack(side=tk.LEFT, padx=PADX)
            except Exception as e:
                logging.error(f"Failed to load logo: {str(e)}")
        title_frame = ttk.Frame(header_frame)
        title_frame.pack(side=tk.LEFT, expand=True, fill=tk.X)
        ttk.Label(title_frame, text="ATS CV Optimizer Pro", font=HEADER_FONT).pack(anchor=tk.W)
        self.result_label = ttk.Label(title_frame, text="ATS Match: -", font=("Arial", 14, "bold"))
        self.result_label.pack(anchor=tk.W)
        dev_frame = ttk.Frame(header_frame)
        dev_frame.pack(side=tk.RIGHT, padx=PADX)
        ttk.Label(dev_frame, text="Developed by Aleksandr Arkhipov", font=DEFAULT_FONT).pack(anchor=tk.E)
        ttk.Label(dev_frame, text="arkhipower@gmail.com", font=DEFAULT_FONT).pack(anchor=tk.E)
        linkedin_label = ttk.Label(
            dev_frame,
            text="LinkedIn: arkhipovhse",
            font=DEFAULT_FONT,
            foreground="blue",
            cursor="hand2"
        )
        linkedin_label.pack(anchor=tk.E)
        linkedin_label.bind("<Button-1>", lambda e: webbrowser.open_new("https://www.linkedin.com/in/arkhipovhse"))

    def create_load_section(self):
        load_frame = ttk.Frame(self.main_frame)
        load_frame.pack(fill=tk.X, pady=5)
        ttk.Button(load_frame, text="Load Your CV (.docx/.pdf)", command=self.load_cv_from_dialog).pack(side=tk.LEFT, padx=2)
        ttk.Button(load_frame, text="Job Description / Other Candidate CV (.docx/.pdf)", command=self.load_jd_from_dialog).pack(side=tk.LEFT, padx=2)

    def create_cv_section(self):
        cv_frame = ttk.LabelFrame(self.main_frame, text="CV Content", padding=10)
        cv_frame.pack(fill=tk.BOTH, expand=True, padx=PADX, pady=PADY)
        self.cv_display = scrolledtext.ScrolledText(
            cv_frame,
            wrap=tk.WORD,
            font=MONOSPACE_FONT,
            height=10,
            state="disabled"
        )
        self.cv_display.pack(fill=tk.BOTH, expand=True)

    def create_action_buttons(self):
        action_frame = ttk.Frame(self.main_frame)
        action_frame.pack(fill=tk.X, pady=5)
        self.analyze_button = ttk.Button(
            action_frame,
            text="Analyze ATS Match",
            command=self.run_analysis,
            state="disabled"
        )
        self.analyze_button.pack(side=tk.LEFT, padx=2)
        self.compare_button = ttk.Button(
            action_frame,
            text="Compare CV vs JD",
            command=self.compare_cv_jd,
            state="disabled"
        )
        self.compare_button.pack(side=tk.LEFT, padx=2)
        self.audit_button = ttk.Button(
            action_frame,
            text="Full AI Audit",
            command=self.run_full_audit,
            state="disabled"
        )
        self.audit_button.pack(side=tk.LEFT, padx=2)
        self.internal_audit_button = ttk.Button(
            action_frame,
            text="Internal Audit",
            command=self.generate_internal_audit,
            state="disabled"
        )
        self.internal_audit_button.pack(side=tk.LEFT, padx=2)
        self.client_summary_button = ttk.Button(
            action_frame,
            text="Client Summary",
            command=self.generate_client_summary,
            state="disabled"
        )
        self.client_summary_button.pack(side=tk.LEFT, padx=2)
        self.improve_button = ttk.Button(
            action_frame,
            text="Improve CV",
            command=self.improve_cv,
            state="disabled"
        )
        self.improve_button.pack(side=tk.LEFT, padx=2)
        self.self_audit_button = ttk.Button(
            action_frame,
            text="CV Self-Audit",
            command=self.generate_cv_self_audit,
            state="disabled"
        )
        self.self_audit_button.pack(side=tk.LEFT, padx=2)

    def create_jd_section(self):
        jd_frame = ttk.LabelFrame(self.main_frame, text=" Job Description / Other Candidate CV / Audit Results", padding=10)
        jd_frame.pack(fill=tk.BOTH, expand=True, padx=PADX, pady=PADY)
        self.jd_display = scrolledtext.ScrolledText(
            jd_frame,
            wrap=tk.WORD,
            font=MONOSPACE_FONT,
            height=10,
            state="disabled"
        )
        self.jd_display.pack(fill=tk.BOTH, expand=True)

    def create_status_bar(self):
        status_frame = ttk.Frame(self.main_frame)
        status_frame.pack(fill=tk.X, pady=5)
        self.status_label = ttk.Label(status_frame, text="Status: Idle", font=DEFAULT_FONT)
        self.status_label.pack(side=tk.LEFT, padx=PADX)

    def create_log_section(self):
        log_frame = ttk.LabelFrame(self.main_frame, text="Activity Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=False, padx=PADX, pady=PADY)
        self.log_display = scrolledtext.ScrolledText(
            log_frame,
            height=8,
            state="disabled",
            font=MONOSPACE_FONT
        )
        self.log_display.pack(fill=tk.BOTH, expand=True)

    def extract_text_from_docx(self, file_path):
        try:
            doc = Document(file_path)
            return '\n'.join([para.text for para in doc.paragraphs if para.text.strip()])
        except Exception as e:
            raise ValueError(f"Failed to read .docx file: {str(e)}")

    def extract_text_from_pdf(self, file_path):
        try:
            with pdfplumber.open(file_path) as pdf:
                return '\n'.join([page.extract_text() or '' for page in pdf.pages])
        except Exception as e:
            raise ValueError(f"Failed to read .pdf file: {str(e)}")

    def extract_text_from_file(self, file_path):
        if os.path.getsize(file_path) > MAX_FILE_SIZE:
            raise ValueError("File size exceeds 10MB limit")
        if file_path.endswith(".docx"):
            return self.extract_text_from_docx(file_path)
        elif file_path.endswith(".pdf"):
            return self.extract_text_from_pdf(file_path)
        else:
            raise ValueError("Unsupported file type: only .docx and .pdf are allowed")

    def clean_text(self, text):
        text = text.lower()
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    def sanitize_text_for_tk(self, text):
        if not isinstance(text, str):
            text = str(text)
        text = unicodedata.normalize('NFKD', text)
        return text.encode('utf-8', errors='replace').decode('utf-8')

    def enhanced_compare_texts(self, cv_text, jd_text):
        try:
            vectorizer = TfidfVectorizer(ngram_range=(1, 3), stop_words='english', max_features=5000)
            tfidf_matrix = vectorizer.fit_transform([cv_text, jd_text])
            base_score = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0] * 100
            weighted_score = self.apply_keyword_weights(cv_text, jd_text, base_score)
            sections_score = self.analyze_sections(cv_text, jd_text)
            final_score = (base_score * 0.4 + weighted_score * 0.4 + sections_score * 0.2)
            return round(final_score, 1)
        except Exception as e:
            logging.error(f"Text comparison failed: {str(e)}")
            return 0.0

    def apply_keyword_weights(self, cv_text, jd_text, base_score):
        weighted_score = base_score
        for keyword, weight in self.keyword_weights.items():
            if keyword in jd_text.lower():
                if keyword in cv_text.lower():
                    weighted_score *= (1 + (weight - 1) * 0.1)
                else:
                    weighted_score *= (1 - (weight - 1) * 0.15)
        return min(100, weighted_score)

    def analyze_sections(self, cv_text, jd_text):
        sections = self.extract_cv_sections(cv_text)
        score = 0
        if 'EXPERIENCE' in sections:
            score += self.match_experience(sections['EXPERIENCE'], jd_text) * 0.4
        if 'SKILLS' in sections:
            score += self.match_skills(sections['SKILLS'], jd_text) * 0.3
        if 'EDUCATION' in sections:
            score += self.match_education(sections['EDUCATION'], jd_text) * 0.2
        return min(100, score * 100)

    def extract_cv_sections(self, text):
        sections = {}
        section_headers = ["experience", "skills", "education", "certifications"]
        text_lower = text.lower()
        for i, header in enumerate(section_headers):
            pattern = rf"\b{header}\b"
            match = re.search(pattern, text_lower, re.IGNORECASE)
            if match:
                start = match.start()
                end = len(text)
                if i + 1 < len(section_headers):
                    next_match = re.search(rf"\b{section_headers[i+1]}\b", text_lower[start:], re.IGNORECASE)
                    if next_match:
                        end = start + next_match.start()
                sections[header.upper()] = text[start:end]
        return sections

    def match_experience(self, exp_text, jd_text):
        exp_match = re.search(r"(\d+)\s*(year|yr|лет)", jd_text, re.IGNORECASE)
        req_exp = int(exp_match.group(1)) if exp_match else 0
        user_exp = 0
        exp_years = re.findall(r"(\d+)\s*(year|yr|лет)", exp_text, re.IGNORECASE)
        if exp_years:
            user_exp = max(int(y[0]) for y in exp_years)
        return 100 if req_exp == 0 else min(100, (user_exp / req_exp) * 100)

    def match_skills(self, skills_text, jd_text):
        normalized_skills = self.normalize_tools(skills_text)
        required_skills = set(re.findall(r"\b([A-Za-z]+ \w+|\w+)\b", jd_text))
        matches = sum(1 for skill in required_skills if any(norm_skill in skill.lower() for norm_skill in normalized_skills))
        return (matches / len(required_skills)) * 100 if required_skills else 100

    def normalize_tools(self, text):
        normalized = []
        for tool, variants in self.tool_mapping.items():
            if any(variant in text.lower() for variant in variants + [tool]):
                normalized.append(tool)
        return normalized

    def match_education(self, edu_text, jd_text):
        edu_keywords = ["bachelor", "master", "phd", "degree", "diploma"]
        req_edu = any(keyword in jd_text.lower() for keyword in edu_keywords)
        has_edu = any(keyword in edu_text.lower() for keyword in edu_keywords)
        return 100 if not req_edu else (100 if has_edu else 0)

    def keyword_check(self, text):
        oil_gas_keywords = [
            "drilling", "petrel", "hse", "safety", "offshore",
            "onshore", "well", "reservoir", "production", "pipeline",
            "simops", "hazop", "nebosh", "iwcf", "pmp",
            "sap", "primavera", "aspen", "cmms", "lims"
        ]
        found = [kw for kw in oil_gas_keywords if kw.lower() in text.lower()]
        missing = [kw for kw in oil_gas_keywords if kw.lower() not in text.lower()]
        return found, missing

    def log_message(self, message):
        timestamp = datetime.now().strftime("[%H:%M:%S] ")
        self.log_display.configure(state="normal")
        self.log_display.insert(tk.END, timestamp + message + "\n")
        self.log_display.configure(state="disabled")
        self.log_display.see(tk.END)
        logging.info(message)

    def show_analysis_window(self, title, content):
        analysis_window = tk.Toplevel(self.root)
        analysis_window.title(title)
        analysis_window.geometry("1000x600")
        text_widget = scrolledtext.ScrolledText(
            analysis_window,
            wrap=tk.WORD,
            font=MONOSPACE_FONT,
            state="normal"
        )
        text_widget.insert(tk.END, content)
        text_widget.configure(state="disabled")
        text_widget.pack(fill=tk.BOTH, expand=True)

    def load_cv_from_dialog(self):
        file_path = filedialog.askopenfilename(filetypes=[("Documents", "*.docx *.pdf")])
        if file_path:
            self.load_cv(file_path)

    def load_jd_from_dialog(self):
        file_path = filedialog.askopenfilename(filetypes=[("Documents", "*.docx *.pdf")])
        if file_path:
            self.load_jd(file_path)

    def load_cv(self, file_path):
        try:
            cv_text = self.extract_text_from_file(file_path)
            cv_text = self.sanitize_text_for_tk(cv_text)
            self.cv_display.configure(state="normal")
            self.cv_display.delete("1.0", tk.END)
            self.cv_display.insert(tk.END, cv_text)
            self.cv_display.configure(state="disabled")
            self.cv_raw = self.clean_text(cv_text)
            self.cv_original = cv_text
            self.log_message(f"CV loaded from {file_path}")
            self.update_button_states()
        except Exception as e:
            error_msg = f"Failed to load CV: {str(e)}"
            messagebox.showerror("Error", error_msg)
            logging.error(error_msg)

    def load_jd(self, file_path):
        try:
            jd_text = self.extract_text_from_file(file_path)
            jd_text = self.sanitize_text_for_tk(jd_text)
            self.jd_display.configure(state="normal")
            self.jd_display.delete("1.0", tk.END)
            self.jd_display.insert(tk.END, jd_text)
            self.jd_display.configure(state="disabled")
            self.jd_raw = self.clean_text(jd_text)
            self.jd_original = jd_text
            self.log_message(f"Job Description loaded from {file_path}")
            self.update_button_states()
        except Exception as e:
            error_msg = f"Failed to load Job Description: {str(e)}"
            messagebox.showerror("Error", error_msg)
            logging.error(error_msg)

    def update_button_states(self):
        has_cv = self.cv_raw is not None
        has_jd = self.jd_raw is not None
        self.analyze_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.compare_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.audit_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.internal_audit_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.client_summary_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.improve_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.self_audit_button.config(state="normal" if has_cv else "disabled")

    def run_ollama_command(self, prompt):
        try:
            if len(prompt) > MAX_PROMPT_LENGTH:
                prompt = prompt[:MAX_PROMPT_LENGTH - 100] + "... [truncated]"
                logging.warning("Prompt truncated to fit max length")
            cmd = ["ollama", "run", "mistral:7b-instruct-v0.2-q5_K_M", prompt]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True,
                encoding='utf-8'
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError as e:
            raise Exception(f"Ollama error: {e.stderr}")
        except Exception as e:
            raise Exception(f"Failed to run Ollama: {str(e)}. Ensure ollama is installed and running.")

    def run_analysis(self):
        if not self.cv_raw or not self.jd_raw:
            messagebox.showwarning("Missing Data", "Please load both CV and Job Description.")
            return
        try:
            self.status_label.config(text="Status: Analyzing...", foreground="orange")
            self.root.update_idletasks()
            start_time = datetime.now()
            self.log_message("Started enhanced ATS match analysis...")
            score = self.enhanced_compare_texts(self.cv_raw, self.jd_raw)
            self.result_label.config(text=f"ATS Match: {score}%")
            self.result_label.config(foreground="green" if score >= 80 else "orange" if score >= 60 else "red")
            required_certs = set(re.findall(r"(API \d+|NEBOSH|IWCF|PMP)", self.jd_original, re.IGNORECASE))
            user_certs = set(re.findall(r"(API \d+|NEBOSH|IWCF|PMP)", self.cv_original, re.IGNORECASE))
            vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
            jd_vector = vectorizer.fit_transform([self.jd_raw])
            feature_names = vectorizer.get_feature_names_out()
            sorted_indices = np.argsort(jd_vector.toarray())[0][-10:]
            top_keywords = [feature_names[i] for i in sorted_indices[::-1]]
            report = f"""
            Enhanced ATS Analysis Report
            ----------------------------
            Overall Match Score: {score}%

            Key Metrics:
            - Missing Certificates: {', '.join(required_certs - user_certs) or 'None'}
            - Present Certificates: {', '.join(user_certs) or 'None'}

            Top 10 Keywords from Job Description:
            {', '.join(top_keywords)}

            Recommendations:
            1. {self.generate_recommendations(score, required_certs - user_certs)}
            2. Focus on improving your {self.get_weakest_area(self.cv_raw, self.jd_raw)} section
            """
            self.show_analysis_window("Enhanced ATS Analysis", report)
            self.log_message(f"Enhanced ATS analysis completed: {score}%")
        except Exception as e:
            error_msg = f"Analysis failed: {str(e)}"
            self.status_label.config(text="Status: Analysis Failed ❌", foreground="red")
            self.log_message(error_msg)
            messagebox.showerror("Error", error_msg)
            logging.error(error_msg)
        finally:
            self.status_label.config(text="Status: Idle", foreground="blue")

    def generate_recommendations(self, score, missing_certs):
        base = {
            80: "Your CV is well aligned. Consider highlighting: ",
            60: "Your CV needs moderate improvements. Focus on: ",
            0: "Your CV requires significant changes. Priority areas: "
        }[next(k for k in [80, 60, 0] if score >= k)]
        return base + (f"obtaining {next(iter(missing_certs))} certification" if missing_certs else "adding more relevant keywords from the job description")

    def get_weakest_area(self, cv_text, jd_text):
        sections = self.extract_cv_sections(cv_text)
        scores = {}
        if 'EXPERIENCE' in sections:
            scores['experience'] = self.match_experience(sections['EXPERIENCE'], jd_text)
        if 'SKILLS' in sections:
            scores['skills'] = self.match_skills(sections['SKILLS'], jd_text)
        return min(scores, key=scores.get) if scores else "skills"

    def compare_cv_jd(self):
        if not self.cv_original or not self.jd_original:
            messagebox.showwarning("Missing Data", "Please load both CV and Job Description.")
            return
        try:
            self.status_label.config(text="Status: Comparing CV vs JD...", foreground="orange")
            self.root.update_idletasks()
            start_time = datetime.now()
            self.log_message("Started CV vs JD comparison using Ollama...")
            prompt = f"""
            [INST]
            Compare the following CV and Job Description in detail. Provide:
            1. Key skills match (present/missing)
            2. Experience alignment
            3. Recommendations for CV improvement
            4. Overall fit score (1-10)

            CV:
            {self.cv_original[:3000]}... [truncated if long]

            Job Description:
            {self.jd_original[:3000]}... [truncated if long]
            [/INST]
            """
            comparison_result = self.run_ollama_command(prompt)
            self.show_analysis_window("CV vs JD Comparison Results", comparison_result)
            self.status_label.config(text="Status: Comparison Completed ✔", foreground="green")
            self.log_message(f"CV vs JD comparison completed in {(datetime.now() - start_time).total_seconds():.2f} seconds")
        except Exception as e:
            error_msg = f"CV vs JD comparison failed: {str(e)}"
            self.status_label.config(text="Status: Comparison Failed ❌", foreground="red")
            self.log_message(error_msg)
            messagebox.showerror("Error", error_msg)
            logging.error(error_msg)
        finally:
            self.status_label.config(text="Status: Idle", foreground="blue")

    def get_user_input(self, title, prompt):
        """Safely get user input using simpledialog with focus handling"""
        try:
            self.root.focus_force()
            dialog = simpledialog.askstring(title, prompt, parent=self.root)
            return dialog
        except Exception as e:
            logging.warning(f"Dialog error: {str(e)}")
            return None

    def run_full_audit(self):
        if not self.cv_original or not self.jd_original:
            messagebox.showwarning("Missing Data", "Please load CV and JD.")
            return
        role = self.get_user_input("Target Role", "Enter target role (e.g., HSE Manager):")
        context = self.get_user_input("Context", "Enter experience/certs/projects (EN):")
        if role is None or context is None:
            messagebox.showwarning("Missing Info", "Operation cancelled or input not provided.")
            return
        try:
            self.status_label.config(text="Status: Running Audit...", foreground="orange")
            self.root.update_idletasks()
            start_time = datetime.now()
            self.log_message("Started full AI audit...")
            found_keywords, missing_keywords = self.keyword_check(self.cv_original)
            prompt = f"""
            {self.prompts["consultant"]}
            [INST]
            Perform a full audit of this CV against the job description for role: {role}

            Context: {context}

            CV:
            {self.cv_original[:3000]}... [truncated if long]

            Job Description:
            {self.jd_original[:3000]}... [truncated if long]

            Found Keywords: {', '.join(found_keywords)}
            Missing Keywords: {', '.join(missing_keywords)}
            [/INST]
            """
            audit = self.run_ollama_command(prompt)
            self.jd_audit = audit
            elapsed = (datetime.now() - start_time).total_seconds()
            self.jd_display.configure(state="normal")
            self.jd_display.delete("1.0", tk.END)
            self.jd_display.insert(tk.END, audit)
            self.jd_display.configure(state="disabled")
            self.show_analysis_window("Full AI Audit Results", audit)
            self.status_label.config(text="Status: Audit Completed ✔", foreground="green")
            self.log_message(f"Audit completed in {elapsed:.2f} seconds.")
            self.update_button_states()
        except Exception as e:
            error_msg = f"Audit failed: {str(e)}"
            self.status_label.config(text="Status: Audit Failed ❌", foreground="red")
            self.log_message(error_msg)
            messagebox.showerror("AI Error", error_msg)
            logging.error(error_msg)
        finally:
            self.status_label.config(text="Status: Idle", foreground="blue")

    def generate_internal_audit(self):
        if not self.cv_original or not self.jd_original:
            messagebox.showwarning("Missing Data", "Please load both CV and JD.")
            return
        role = self.get_user_input("Target Role", "Enter target role (e.g., HSE Manager):")
        context = self.get_user_input("Context", "Enter experience/certs/projects (EN):")
        if role is None or context is None:
            messagebox.showwarning("Missing Info", "Operation cancelled or input not provided.")
            return
        try:
            self.status_label.config(text="Status: Generating Internal Audit...", foreground="orange")
            self.root.update_idletasks()
            start_time = datetime.now()
            self.log_message("Started Internal Audit generation...")
            found, missing = self.keyword_check(self.cv_original)
            prompt = f"""
            {self.prompts["consultant"]}
            [INST]
            Generate an internal technical audit for role: {role}

            Context: {context}

            CV:
            {self.cv_original[:3000]}... [truncated if long]

            Job Description:
            {self.jd_original[:3000]}... [truncated if long]
            [/INST]
            """
            audit = self.run_ollama_command(prompt)
            internal_audit = audit
            if "---" in audit:
                internal_audit = audit.split("---")[0].strip()
            elif "Internal Full Audit Report" in audit:
                internal_audit = re.split(r"Client Summary Report|PART 2", audit, flags=re.IGNORECASE)[0].strip()
            elapsed = (datetime.now() - start_time).total_seconds()
            self.jd_display.configure(state="normal")
            self.jd_display.delete("1.0", tk.END)
            self.jd_display.insert(tk.END, internal_audit)
            self.jd_display.configure(state="disabled")
            self.show_analysis_window("Internal Audit Results", internal_audit)
            self.status_label.config(text="Status: Internal Audit Completed ✔", foreground="green")
            self.log_message(f"Internal Audit completed in {elapsed:.2f} seconds.")
            self.update_button_states()
        except Exception as e:
            error_msg = f"Internal Audit failed: {str(e)}"
            self.status_label.config(text="Status: Internal Audit Failed ❌", foreground="red")
            self.log_message(error_msg)
            messagebox.showerror("AI Error", error_msg)
            logging.error(error_msg)
        finally:
            self.status_label.config(text="Status: Idle", foreground="blue")

    def generate_client_summary(self):
        if not self.cv_original or not self.jd_original:
            messagebox.showwarning("Missing Data", "Please load both CV and JD.")
            return
        role = self.get_user_input("Target Role", "Enter target role (e.g., HSE Manager):")
        context = self.get_user_input("Context", "Enter experience/certs/projects (EN):")
        if role is None or context is None:
            messagebox.showwarning("Missing Info", "Operation cancelled or input not provided.")
            return
        try:
            self.status_label.config(text="Status: Generating Client Summary...", foreground="orange")
            self.root.update_idletasks()
            start_time = datetime.now()
            self.log_message("Started Client Summary generation...")
            found, missing = self.keyword_check(self.cv_original)
            prompt = f"""
            {self.prompts["client"]}
            [INST]
            Generate a client-friendly summary for role: {role}

            Context: {context}

            CV:
            {self.cv_original[:3000]}... [truncated if long]

            Job Description:
            {self.jd_original[:3000]}... [truncated if long]
            [/INST]
            """
            audit = self.run_ollama_command(prompt)
            client_summary = audit
            if "---" in audit:
                client_summary = audit.split("---")[1].strip() if len(audit.split("---")) > 1 else audit
            elif "Client Summary Report" in audit:
                client_summary = re.split(r"Client Summary Report", audit, flags=re.IGNORECASE)[1].strip()
            elapsed = (datetime.now() - start_time).total_seconds()
            self.jd_display.configure(state="normal")
            self.jd_display.delete("1.0", tk.END)
            self.jd_display.insert(tk.END, client_summary)
            self.jd_display.configure(state="disabled")
            self.show_analysis_window("Client Summary Results", client_summary)
            self.status_label.config(text="Status: Client Summary Completed ✔", foreground="green")
            self.log_message(f"Client Summary completed in {elapsed:.2f} seconds.")
            self.update_button_states()
        except Exception as e:
            error_msg = f"Client Summary failed: {str(e)}"
            self.status_label.config(text="Status: Client Summary Failed ❌", foreground="red")
            self.log_message(error_msg)
            messagebox.showerror("AI Error", error_msg)
            logging.error(error_msg)
        finally:
            self.status_label.config(text="Status: Idle", foreground="blue")

    def improve_cv(self):
        if not self.cv_original or not self.jd_original:
            messagebox.showwarning("Missing Data", "Please load both CV and JD.")
            return
        role = self.get_user_input("Target Role", "Enter target role (e.g., HSE Manager):")
        context = self.get_user_input("Context", "Enter experience/certs/projects (EN):")
        if role is None or context is None:
            messagebox.showwarning("Missing Info", "Operation cancelled or input not provided.")
            return
        try:
            self.status_label.config(text="Status: Improving CV...", foreground="orange")
            self.root.update_idletasks()
            start_time = datetime.now()
            self.log_message("Started CV improvement...")
            found, missing = self.keyword_check(self.cv_original)
            prompt = f"""
            {self.prompts["optimization"]}
            [INST]
            Optimize this CV for role: {role}

            Context: {context}

            Original CV:
            {self.cv_original[:3000]}... [truncated if long]

            Job Description:
            {self.jd_original[:3000]}... [truncated if long]

            Missing Keywords: {', '.join(missing)}
            [/INST]
            """
            optimized = self.run_ollama_command(prompt)
            hidden_keywords = found + missing
            hidden_section = "\n\n[ATS Keywords (Hidden)]\n" + ", ".join(hidden_keywords)
            self.cv_improved = optimized + hidden_section
            elapsed = (datetime.now() - start_time).total_seconds()
            self.cv_display.configure(state="normal")
            self.cv_display.delete("1.0", tk.END)
            self.cv_display.insert(tk.END, self.cv_improved)
            self.cv_display.configure(state="disabled")
            self.show_analysis_window("Improved CV Results", self.cv_improved)
            self.status_label.config(text="Status: CV Improvement Completed ✔", foreground="green")
            self.log_message(f"CV improvement completed in {elapsed:.2f} seconds.")
            self.update_button_states()
        except Exception as e:
            error_msg = f"CV improvement failed: {str(e)}"
            self.status_label.config(text="Status: CV Improvement Failed ❌", foreground="red")
            self.log_message(error_msg)
            messagebox.showerror("AI Error", error_msg)
            logging.error(error_msg)
        finally:
            self.status_label.config(text="Status: Idle", foreground="blue")

    def generate_cv_self_audit(self):
        if not self.cv_original:
            messagebox.showwarning("Missing Data", "Please load a CV.")
            return
        role = self.get_user_input("Target Role", "Enter target role (e.g., HSE Manager):")
        context = self.get_user_input("Context", "Enter experience/certs/projects (EN):")
        if role is None or context is None:
            messagebox.showwarning("Missing Info", "Operation cancelled or input not provided.")
            return
        try:
            self.status_label.config(text="Status: Generating CV Self-Audit...", foreground="orange")
            self.root.update_idletasks()
            start_time = datetime.now()
            self.log_message("Started CV Self-Audit generation...")
            found, missing = self.keyword_check(self.cv_original)
            prompt = f"""
            {self.prompts["self_audit"]}
            [INST]
            Analyze this CV for role: {role}

            Context: {context}

            CV:
            {self.cv_original[:3000]}... [truncated if long]

            Found Keywords: {', '.join(found)}
            Missing Keywords: {', '.join(missing)}
            [/INST]
            """
            audit = self.run_ollama_command(prompt)
            elapsed = (datetime.now() - start_time).total_seconds()
            self.jd_display.configure(state="normal")
            self.jd_display.delete("1.0", tk.END)
            self.jd_display.insert(tk.END, audit)
            self.jd_display.configure(state="disabled")
            self.show_analysis_window("CV Self-Audit Results", audit)
            self.status_label.config(text="Status: CV Self-Audit Completed ✔", foreground="green")
            self.log_message(f"CV Self-Audit completed in {elapsed:.2f} seconds.")
            self.update_button_states()
        except Exception as e:
            error_msg = f"CV Self-Audit failed: {str(e)}"
            self.status_label.config(text="Status: CV Self-Audit Failed ❌", foreground="red")
            self.log_message(error_msg)
            messagebox.showerror("AI Error", error_msg)
            logging.error(error_msg)
        finally:
            self.status_label.config(text="Status: Idle", foreground="blue")

if __name__ == "__main__":
    root = tk.Tk()
    app = ATSOptimizerApp(root)
    root.mainloop()