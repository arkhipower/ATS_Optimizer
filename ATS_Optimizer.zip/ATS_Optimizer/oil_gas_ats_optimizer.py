
### Updated Code for `oil_gas_ats_optimizer.py`
<xaiable_artifact_id="d3d09d59-7b6d-4ba2-b4de-7cbc28a8b12b" title="oil_gas_ats_optimizer.py" contentType="text/python">
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext, simpledialog
import os
import subprocess
import threading
from datetime import datetime
from docx import Document
import pdfplumber
import re
import logging
import unicodedata
import sys

# --- Constants ---
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB limit
MAX_PROMPT_LENGTH = 8000  # Max chars for ollama prompt

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='ats_optimizer.log'
)

# Default prompts if files are missing
DEFAULT_PROMPTS = {
    "consultant": "[INST] Perform a technical audit of the CV for the specified role, analyzing ATS compatibility, keywords, and job alignment. Provide an ATS score (1-10), keyword audit, and improvement suggestions. [/INST]",
    "client": "[INST] Generate a client-friendly summary for the specified role, highlighting CV strengths, ATS compatibility (1-10), and top missed opportunities. Include a call to action. [/INST]",
    "optimization": "[INST] Optimize the CV for the specified role, creating an ATS-compliant version with a header, summary, skills, experience, certifications, education, tools, and languages. Use .docx-safe formatting. [/INST]"
}

class ATSOptimizerApp:
    def __init__(self, root):
        self.root = root
        self.check_dependencies()  # Check dependencies at startup
        self.setup_logging()
        self.load_prompts()
        self.setup_ui()
        self.setup_variables()

    def check_dependencies(self):
        """Check for required dependencies and alert user if missing"""
        try:
            import pdfplumber
            import docx
        except ImportError as e:
            messagebox.showerror("Dependency Error", f"Missing dependency: {str(e)}. Please install required packages (pdfplumber, python-docx).")
            sys.exit(1)
        try:
            subprocess.run(["ollama", "--version"], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            messagebox.showerror("Ollama Error", "Ollama is not installed or not running. Install ollama and run 'ollama pull mistral:7b-instruct-v0.2-q5_K_M'.")
            sys.exit(1)

    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            filename='ats_optimizer.log'
        )

    def load_prompts(self):
        """Load prompt templates from files with fallback"""
        self.prompts = {}
        prompt_files = {
            "consultant": "prompt_audit_consultant.txt",
            "client": "prompt_audit_client.txt",
            "optimization": "prompt_audit_optimization.txt"
        }
        # Get the directory of the script
        script_dir = os.path.dirname(os.path.abspath(__file__))
        for key, filename in prompt_files.items():
            try:
                file_path = os.path.join(script_dir, filename)
                if os.path.exists(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        self.prompts[key] = f.read()
                else:
                    logging.warning(f"Prompt file not found: {file_path}. Using default prompt.")
                    self.prompts[key] = DEFAULT_PROMPTS[key]
                    messagebox.showwarning("Prompt Warning", f"Prompt file {filename} not found. Using default prompt.")
            except Exception as e:
                logging.error(f"Error loading prompt {filename}: {str(e)}")
                self.prompts[key] = DEFAULT_PROMPTS[key]
                messagebox.showwarning("Prompt Error", f"Error loading {filename}. Using default prompt.")

    def setup_variables(self):
        self.cv_content = ""
        self.jd_content = ""
        self.audit_results = ""
        self.optimized_cv = ""

    def setup_ui(self):
        self.root.title("Oil & Gas ATS Optimizer Pro")
        self.root.geometry("1200x800")
        self.style = ttk.Style()
        self.style.configure("TButton", font=('Helvetica', 10, 'bold'))
        self.style.configure("TLabel", font=('Helvetica', 10))
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        self.create_input_tab()
        self.create_audit_tab()
        self.create_optimization_tab()
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN).pack(fill=tk.X)

    def create_input_tab(self):
        input_tab = ttk.Frame(self.notebook)
        self.notebook.add(input_tab, text="Input")
        cv_frame = ttk.LabelFrame(input_tab, text="CV Content", padding=10)
        cv_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.load_cv_button = ttk.Button(cv_frame, text="Load CV", command=self.load_cv)
        self.load_cv_button.pack(anchor=tk.NW, pady=5)
        self.cv_text = scrolledtext.ScrolledText(cv_frame, wrap=tk.WORD, height=15, state='normal')
        self.cv_text.pack(fill=tk.BOTH, expand=True)
        jd_frame = ttk.LabelFrame(input_tab, text="Job Description", padding=10)
        jd_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.load_jd_button = ttk.Button(jd_frame, text="Load Job Description", command=self.load_jd)
        self.load_jd_button.pack(anchor=tk.NW, pady=5)
        self.jd_text = scrolledtext.ScrolledText(jd_frame, wrap=tk.WORD, height=15, state='normal')
        self.jd_text.pack(fill=tk.BOTH, expand=True)

    def create_audit_tab(self):
        audit_tab = ttk.Frame(self.notebook)
        self.notebook.add(audit_tab, text="Audit")
        control_frame = ttk.Frame(audit_tab)
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        self.audit_button = ttk.Button(
            control_frame,
            text="Run Internal Audit",
            command=lambda: threading.Thread(target=self.run_internal_audit, daemon=True).start(),
            state="disabled"
        )
        self.audit_button.pack(side=tk.LEFT)
        self.summary_button = ttk.Button(
            control_frame,
            text="Generate Client Summary",
            command=lambda: threading.Thread(target=self.generate_client_summary, daemon=True).start(),
            state="disabled"
        )
        self.summary_button.pack(side=tk.LEFT)
        self.audit_results_text = scrolledtext.ScrolledText(
            audit_tab,
            wrap=tk.WORD,
            height=25,
            state='disabled'
        )
        self.audit_results_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def create_optimization_tab(self):
        opt_tab = ttk.Frame(self.notebook)
        self.notebook.add(opt_tab, text="Optimization")
        control_frame = ttk.Frame(opt_tab)
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        self.optimize_button = ttk.Button(
            control_frame,
            text="Optimize CV",
            command=lambda: threading.Thread(target=self.optimize_cv, daemon=True).start(),
            state="disabled"
        )
        self.optimize_button.pack(side=tk.LEFT)
        self.optimized_cv_text = scrolledtext.ScrolledText(
            opt_tab,
            wrap=tk.WORD,
            height=25,
            state='normal'
        )
        self.optimized_cv_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def clean_text(self, text):
        text = text.lower()
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    def sanitize_text_for_tk(self, text):
        if not isinstance(text, str):
            text = str(text)
        text = unicodedata.normalize('NFKD', text)
        return text.encode('utf-8', errors='replace').decode('utf-8')

    def load_cv(self):
        filepath = filedialog.askopenfilename(filetypes=[("Documents", "*.docx *.pdf *.txt")])
        if filepath:
            try:
                if os.path.getsize(filepath) > MAX_FILE_SIZE:
                    raise ValueError("File size exceeds 10MB limit")
                if filepath.endswith('.docx'):
                    doc = Document(filepath)
                    content = '\n'.join([para.text for para in doc.paragraphs])
                elif filepath.endswith('.pdf'):
                    with pdfplumber.open(filepath) as pdf:
                        content = '\n'.join([page.extract_text() or '' for page in pdf.pages])
                else:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                content = self.sanitize_text_for_tk(content)
                self.cv_content = content
                self.cv_text.delete(1.0, tk.END)
                self.cv_text.insert(tk.END, content)
                self.status_var.set(f"Loaded CV: {os.path.basename(filepath)}")
                logging.info(f"CV loaded from {filepath}")
                self.update_button_states()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load CV: {str(e)}")
                logging.error(f"CV load error: {str(e)}")

    def load_jd(self):
        filepath = filedialog.askopenfilename(filetypes=[("Documents", "*.docx *.pdf *.txt")])
        if filepath:
            try:
                if os.path.getsize(filepath) > MAX_FILE_SIZE:
                    raise ValueError("File size exceeds 10MB limit")
                if filepath.endswith('.docx'):
                    doc = Document(filepath)
                    content = '\n'.join([para.text for para in doc.paragraphs])
                elif filepath.endswith('.pdf'):
                    with pdfplumber.open(filepath) as pdf:
                        content = '\n'.join([page.extract_text() or '' for page in pdf.pages])
                else:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                content = self.sanitize_text_for_tk(content)
                self.jd_content = content
                self.jd_text.delete(1.0, tk.END)
                self.jd_text.insert(tk.END, content)
                self.status_var.set(f"Loaded JD: {os.path.basename(filepath)}")
                logging.info(f"Job Description loaded from {filepath}")
                self.update_button_states()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load Job Description: {str(e)}")
                logging.error(f"JD load error: {str(e)}")

    def update_button_states(self):
        has_cv = bool(self.cv_content)
        has_jd = bool(self.jd_content)
        self.audit_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.summary_button.config(state="normal" if has_cv and has_jd else "disabled")
        self.optimize_button.config(state="normal" if has_cv and has_jd else "disabled")

    def run_internal_audit(self):
        if not self.cv_content or not self.jd_content:
            messagebox.showwarning("Warning", "Please load both CV and Job Description")
            return
        try:
            self.status_var.set("Running Internal Audit...")
            self.update_audit_display("Running internal audit...\n")
            role = simpledialog.askstring("Input", "Enter target role:")
            if not role:
                messagebox.showwarning("Warning", "Target role is required.")
                return
            prompt = self.prompts.get("consultant", "") + f"""
            [INST]
            Perform technical audit for role: {role}

            CV Content:
            {self.cv_content[:3000]}... [truncated if long]

            Job Description:
            {self.jd_content[:3000]}... [truncated if long]
            [/INST]
            """
            if len(prompt) > MAX_PROMPT_LENGTH:
                prompt = prompt[:MAX_PROMPT_LENGTH - 100] + "... [truncated]"
                logging.warning("Prompt truncated to fit max length")
            result = self.run_ollama_command(prompt)
            # Flexible parsing with fallback
            internal_audit = result
            if "---" in result:
                internal_audit = result.split("---")[0].strip()
            elif "Internal Full Audit Report" in result:
                internal_audit = re.split(r"Client Summary Report|PART 2", result, flags=re.IGNORECASE)[0].strip()
            self.audit_results = internal_audit
            self.update_audit_display(internal_audit)
            self.status_var.set("Internal Audit Completed")
            logging.info("Internal audit completed")
        except Exception as e:
            error_msg = f"Audit failed: {str(e)}"
            self.update_audit_display(f"\nError: {error_msg}")
            self.status_var.set("Audit Failed")
            logging.error(error_msg)

    def generate_client_summary(self):
        if not self.cv_content or not self.jd_content:
            messagebox.showwarning("Warning", "Please load both CV and Job Description")
            return
        try:
            self.status_var.set("Generating Client Summary...")
            self.update_audit_display("Generating client summary...\n")
            role = simpledialog.askstring("Input", "Enter target role:")
            if not role:
                messagebox.showwarning("Warning", "Target role is required.")
                return
            prompt = self.prompts.get("client", "") + f"""
            [INST]
            Generate client summary for role: {role}

            CV Content:
            {self.cv_content[:3000]}... [truncated if long]

            Job Description:
            {self.jd_content[:3000]}... [truncated if long]
            [/INST]
            """
            if len(prompt) > MAX_PROMPT_LENGTH:
                prompt = prompt[:MAX_PROMPT_LENGTH - 100] + "... [truncated]"
                logging.warning("Prompt truncated to fit max length")
            result = self.run_ollama_command(prompt)
            # Flexible parsing with fallback
            client_summary = result
            if "---" in result:
                client_summary = result.split("---")[1].strip() if len(result.split("---")) > 1 else result
            elif "Client Summary Report" in result:
                client_summary = re.split(r"Client Summary Report", result, flags=re.IGNORECASE)[1].strip()
            self.audit_results = client_summary
            self.update_audit_display(client_summary)
            self.status_var.set("Client Summary Completed")
            logging.info("Client summary generated")
        except Exception as e:
            error_msg = f"Summary failed: {str(e)}"
            self.update_audit_display(f"\nError: {error_msg}")
            self.status_var.set("Summary Failed")
            logging.error(error_msg)

    def optimize_cv(self):
        if not self.cv_content or not self.jd_content:
            messagebox.showwarning("Warning", "Please load both CV and Job Description")
            return
        try:
            self.status_var.set("Optimizing CV...")
            self.optimized_cv_text.delete(1.0, tk.END)
            self.optimized_cv_text.insert(tk.END, "Optimizing CV...\n")
            role = simpledialog.askstring("Input", "Enter target role:")
            if not role:
                messagebox.showwarning("Warning", "Target role is required.")
                return
            prompt = self.prompts.get("optimization", "") + f"""
            [INST]
            Optimize this CV for role: {role}

            Original CV:
            {self.cv_content[:3000]}... [truncated if long]

            Job Description:
            {self.jd_content[:3000]}... [truncated if long]
            [/INST]
            """
            if len(prompt) > MAX_PROMPT_LENGTH:
                prompt = prompt[:MAX_PROMPT_LENGTH - 100] + "... [truncated]"
                logging.warning("Prompt truncated to fit max length")
            result = self.run_ollama_command(prompt)
            self.optimized_cv = result
            self.optimized_cv_text.delete(1.0, tk.END)
            self.optimized_cv_text.insert(tk.END, result)
            self.status_var.set("CV Optimization Completed")
            logging.info("CV optimization completed")
        except Exception as e:
            error_msg = f"Optimization failed: {str(e)}"
            self.optimized_cv_text.insert(tk.END, f"\nError: {error_msg}")
            self.status_var.set("Optimization Failed")
            logging.error(error_msg)

    def run_ollama_command(self, prompt):
        try:
            cmd = ["ollama", "run", "mistral:7b-instruct-v0.2-q5_K_M", prompt]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                check=True
            )
            return result.stdout
        except Exception as e:
            logging.error(f"Ollama command failed: {str(e)}")
            raise Exception(f"Failed to execute Ollama: {str(e)}. Ensure ollama is installed and running.")

    def update_audit_display(self, text):
        self.audit_results_text.config(state='normal')
        self.audit_results_text.delete(1.0, tk.END)
        self.audit_results_text.insert(tk.END, text)
        self.audit_results_text.config(state='disabled')
        self.audit_results_text.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = ATSOptimizerApp(root)
    root.mainloop()
</xaiArtifact>

### Key Changes
- **Updated `load_prompts` Method**: In both scripts, the `load_prompts` method now uses `os.path.dirname(os.path.abspath(__file__))` to get the script's directory and constructs the full path to prompt files with `os.path.join`. This ensures prompt files are loaded from the script's directory, fixing the issue where prompts were not found due to an incorrect working directory.
- **No Other Changes**: The rest of the code remains identical to the provided versions, as they already include robust error handling, default prompts, and other fixes from previous corrections.
- **Artifact IDs**: Reused the same `artifact_id` values (`e8e616e0-d894-4936-a3f5-391682ee794c` for `ats_cv_optimizer_pro.py` and `d3d09d59-7b6d-4ba2-b4de-7cbc28a8b12b` for `oil_gas_ats_optimizer.py`) since these are updated versions of the same artifacts.

### Instructions
1. **Save the Files**:
   - Save the first script as `ats_cv_optimizer_pro.py`.
   - Save the second script as `oil_gas_ats_optimizer.py`.
   - Place both scripts in the same directory (e.g., `ATS_Optimizer/`).

2. **Place Prompt Files**:
   - Ensure the prompt files (`prompt_audit_consultant.txt`, `prompt_audit_client.txt`, `prompt_audit_optimization.txt`) are in the same directory as the scripts.
   - Example directory structure: